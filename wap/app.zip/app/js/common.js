define(['angularAMD', 
        'angular',
	   	'angular-ui-router',
		'restangular',
		//'ng-table',
		'angular-strap',
		'customUtilJS',
		'app/controllers/common/AccordionMenuController',

		], function(angularAMD) {
	'use strict';
	return angularAMD;
});