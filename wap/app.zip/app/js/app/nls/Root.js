define({
    "root": {
        "demoKey": "demoValue"
    },
    "en": true,
    "zh": true
});